<?php
//session_start();

//Conexion a la Base de Datos
$conn = mysqli_connect(
  'localhost',
  'root',//usuario
  '',//contraseña
  'dolibarr'//base de datos
) or die(mysqli_erro($mysqli));


?>
