<?php
//session_start();

//Conexion a la Base de Datos

$conn = mysqli_connect(
  'localhost',
  'ultimate',//usuario
  'Ultmplataforma12A',//contraseña
  'ultimate_dolibarr'//base de datos
) or die(mysqli_erro($mysqli));




?>
